## Files:

1. EXE File: GAD.exe file for WIndows OS Users

2. APP File: GAD.app file for MacOS Users

